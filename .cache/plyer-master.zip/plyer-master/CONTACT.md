.. _contact:

Contact Us
==========

If you are looking to contact the Kivy Team (who are responsible for managing the
Plyer project), including looking for support, please see our
`latest contact details <https://github.com/kivy/kivy/blob/master/CONTACT.md>`_.