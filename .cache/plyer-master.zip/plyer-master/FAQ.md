# FAQ for Plyer

## Introduction

Plyer is a platform-independent Python API for accessing hardware features
of various platforms (Android, iOS, macOS, Linux and Windows).

Plyer is managed by the [Kivy Team](https://kivy.org/about.html). It is suitable for
use with Kivy apps, but can be used independently.

## No questions yet

No Frequently Asked Questions have been identified yet. Please contribute some.
