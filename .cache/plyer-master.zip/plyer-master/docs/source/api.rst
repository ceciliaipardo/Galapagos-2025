
.. _api:

API
===

.. automodule:: plyer
    :members:

.. automodule:: plyer.facades
    :members:
