.. _faq:

FAQ
===

Plyer has an `online FAQ <https://github.com/kivy/plyer/blob/master/FAQ.md>`_. It contains the answers to
questions that repeatedly come up.
